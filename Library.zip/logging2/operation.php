<html>
<head>
        <title> test page</title>
        <link rel="stylesheet" type="text/css" href="in.css">
</head>
<body>
<center>
<div class="header">
  	<h2> Welcome to Operations Menu</h2>
  </div>
  <form>
      <div class="operation">
           <button type="submit" class="btn" name="operating"><a href="borrowing.php">Borrowing book</a></button><br>
      </div>
      <br>
      <div class="operation">
           <button type="submit" class="btn" name="operating"><a href="returning.php">Returning book</a></button><br>
      </div>
      <br>
      <div class="operation">
           <button type="submit" class="btn" name="operating"><a href="extending.php">Extending borrowing period</a></button><br>
      </div>
  </form>
  </center>
</body>
</html>
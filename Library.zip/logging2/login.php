<?php include('server.php')
session_start();
if(!empty($_POST["login"])) {
	$conn = mysqli_connect("localhost", "root", "", "blog_samples");
	$sql = "Select * from members where username = '" . $_POST["username"] . "'";
        if(!isset($_COOKIE["login"])) {
            $sql .= " AND password = '" . md5($_POST["password"]) . "'";
	}
        $result = mysqli_query($conn,$sql);
	$user = mysqli_fetch_array($result);
	if($user) {
			$_SESSION["member_id"] = $user["member_id"];
			
			if(!empty($_POST["remember"])) {
				setcookie ("member_login",$_POST["username"],time()+ (10 * 365 * 24 * 60 * 60));
			} else {
				if(isset($_COOKIE["member_login"])) {
					setcookie ("member_login","");
				}
			}
	} else {
		$message = "Invalid Login";
	}
} ?>
<!DOCTYPE html>
<html>

<head>
  <title>Library Log in</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
  <div class="header">
  	<h2>Login</h2>
  </div>
	 
  <form action="login.php" method="post" id="frmlogin">
  <div class="error-message"><?php if(isset($message)) { echo $message; } ?></div>
	  <?php include('errors.php');  ?>

  	<div class="input-group">
  		<label for="login">Username</label>
  		<input type="text" name="username" value="<?php if(isset($_COOKIE["member_login"])) { echo $_COOKIE["member_login"]; } ?>" class="input-field">

  	</div>

  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="password">
  	</div>
	  <div class="input-group">
		<div><input type="checkbox" name="remember" id="remember" <?php if(isset($_COOKIE["login"])) { ?> checked <?php } ?> />
		<label for="remember-me">Remember me</label>
	</div>

  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>

  	<p>
  		Not yet a member? <a href="register.php">Sign up</a>
  	</p>
  </form>
</body>
</html>